'''
Name: Anshuman Arun
Class: Friday 1st Block Advanced Programming
Date: 5/9/2024
Final Project Desciption: This is a GUI for the SpotDL command line module
'''

import requests
import os
# this is the model for the GUI. It handles all the Client ID/secret stuff and also searching for the song from spotify API

class SpotDLModel:
    def __init__(self):
        self.access_token = self.get_access_token()
    #gets an access token for the spotify API using client_id and client_secret for a project. I got the exact formatting from https://stackoverflow.com/questions/75286588/spotify-web-api-call-gives-wrong-code-python/75292843#75292843
    def get_access_token(self):
        #the spotify client id and client secret are for my developer spotify app: https://developer.spotify.com/dashboard/73538f7868824cb0afa45f00701bacd0
        client_id = os.getenv('SPOTIFY_CLIENT_ID')
        client_secret = os.getenv('SPOTIFY_CLIENT_SECRET')

        #formats the token url/payoload using the client ID and secret
        token_url = 'https://accounts.spotify.com/api/token'
        payload = {
            'grant_type': 'client_credentials',
            'client_id': client_id,
            'client_secret': client_secret
        }
        #uses the requests module to contact the API w/ the access token and checks that there is a result frrom the spotify API
        response = requests.post(token_url, data=payload)
        if response.status_code == 200:
            return response.json()['access_token']
        else:
            #no API token
            print("Error obtaining access token:", response.text)
            return None

    def search_spotify(self, query):
        # makes another request using the requests module for after the song is inputted. This returns all the results which match the user's input
        url = "https://api.spotify.com/v1/search"
        headers = {"Authorization": f"Bearer {self.access_token}"}
        params = {"q": query, "type": "track", "limit": 10}
        response = requests.get(url, headers=headers, params=params)

        #makes sure that there is a song which matches the user input
        if response.status_code == 200:
            return response.json()
        else:
            print("Error searching for tracks:", response.text)
            return None
