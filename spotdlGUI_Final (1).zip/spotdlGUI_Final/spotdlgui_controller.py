'''
Name: Anshuman Arun
Class: Friday 1st Block Advanced Programming
Date: 5/9/2024
Final Project Desciption: This is a GUI for the SpotDL command line module
'''

from PyQt6.QtWidgets import QMessageBox
import subprocess
# this is the controller for the GUI. It connects all of the buttons and defines methods to search for songs and download them using the spotDL module
class SpotDLController:
    #takes in the model and view classes
    def __init__(self, model, view):
        self.model = model
        self.view = view
        # these are the names of the different buttons with the help, search (on the homepage), download, and search (after the user input is submitted)
        # each button links to a different method in the controller
        #not sure whether this should be in __init__ but it seems to work
        self.view.search_button_home.clicked.connect(self.search_button_clicked)
        self.view.help_button_home.clicked.connect(self.help_button_clicked)
        self.view.search_button.clicked.connect(self.search_song)
        self.view.download_button.clicked.connect(self.download_song)

    def search_button_clicked(self):
        # this switches the GUI from the homepage to the search songs interface. I didn't figure out how exactly to switch screens using the QT designer, 
        # so I used this video https://www.youtube.com/watch?v=SelawmXHtPg&ab_channel=JieJenn to figure out how to define the pages and buttons separately and how to switch between the different pages
        self.view.switch_to_search()

    #creates a help button using the Qmessagebox button 
    def help_button_clicked(self):
        help_text = "This application allows you to search for songs on Spotify and download them. Here's how to use it:\n\n1. On the home screen, click 'Search for a Song' to enter the search screen.\n2. In the search screen, type the name of the song you want to search for in the search input field and click 'Search'.\n3. The search results will appear in the list below. Click on a song to select it.\n4. After selecting a song, click 'Download Selected' to start the download process.\n\nThis project needs the SpotDL module to be installed. Go to https://github.com/spotDL/spotify-downloader and follow the instructions to download the module."
        QMessageBox.information(self.view, 'Help', help_text)

    #this is the part which controls the list of songs showing up after the spotify API is reached and responds back
    def search_song(self):
        #input is the user input
        input = self.view.search_input.text()
        #checks that there is actually in input to make sure that the user doesn't press search without any actual input
        if input:
            results = self.model.search_spotify(input)
            #calls the show_search_results from the view to show search results
            self.view.show_search_results(results)
        #tells the user to input
        else:
            print("Please enter a search input")

    #this handles the actual download of the song. It gives the SpotDL module a spotify link (which always starts with the string "open.spotify.com/track" and then the track id, which is unique to every track)
    def download_song(self):
        #defines the current selected item
        selected_item = self.view.search_results.currentItem()
        #after a song is selected
        if selected_item:
            #the track ID is very specific, and I got the syntax from this forum: https://stackoverflow.com/questions/38664235/how-to-look-up-spotify-ids-song-track-ids-in-bulk
            track_id = selected_item.data(1000)
            if track_id:
                #creates the url to feed to spotDL
                url = "open.spotify.com/track/"+ str(track_id)
                #subprocess runs the module with the url
                subprocess.run(['spotdl', url])
            #handles errors for wrong entries if there is no actual track ID
            else:
                print("Selected item does not contain track ID")
        #if there is no item selected, then the person needs to select an item
        else:
            print("Please select a song from the search results")
