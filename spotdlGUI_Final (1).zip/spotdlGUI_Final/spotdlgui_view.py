'''
Name: Anshuman Arun
Class: Friday 1st Block Advanced Programming
Date: 5/9/2024
Final Project Desciption: This is a GUI for the SpotDL command line module
'''

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QMainWindow, QLineEdit, QListWidget, QListWidgetItem

# this is the view for the GUI. It handles all the GUI buttons and things like that

class SpotDLView(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        #creates a window
        self.setWindowTitle('SpotDL GUI')
        self.setGeometry(100, 100, 400, 400)

        #creates main window
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        #creates home screen with the a descripiton of the GUI and also a help button and a search button
        self.home_widget = QWidget()
        self.home_layout = QVBoxLayout()

        # description of the GUI
        self.description_label = QLabel("Welcome to SpotDL GUI!\nThis application allows you to search for songs on Spotify and download them.")
        self.home_layout.addWidget(self.description_label)

        # help button which gives some more information
        self.help_button_home = QPushButton('Help')
        self.home_layout.addWidget(self.help_button_home)

        # Search Button (this button is on the homescreen and switches to the search screen)
        self.search_button_home = QPushButton('Search for a Song')
        self.home_layout.addWidget(self.search_button_home)
        self.home_widget.setLayout(self.home_layout)

        # Search Button 2 (this button is in the search screen)
        self.search_widget = QWidget()
        self.search_layout = QVBoxLayout()

        # parts of the search screen (text telling the user to search for a song)
        self.search_label = QLabel('Search for a song:')
        self.search_layout.addWidget(self.search_label)

        #search box
        self.search_input = QLineEdit()
        self.search_layout.addWidget(self.search_input)

        #search button
        self.search_button = QPushButton('Search')
        self.search_layout.addWidget(self.search_button)

        #list of results after search
        self.search_results = QListWidget()
        self.search_layout.addWidget(self.search_results)

        #button to download
        self.download_button = QPushButton('Download Selected')
        self.search_layout.addWidget(self.download_button)

        self.search_widget.setLayout(self.search_layout)

        # Set Home Screen as Initial Widget
        self.set_home_screen()

    #method to set up the homescreen
    def set_home_screen(self):
        self.setCentralWidget(self.home_widget)

    #method to set up the search screen
    def set_search_screen(self):
        self.setCentralWidget(self.search_widget)

    #method to switch from the homescreen to the search screen
    def switch_to_search(self):
        self.set_search_screen()

    #gives the list of search results, formatted since Spotify API doesn't auto fromat
    def show_search_results(self, results:dict):
        #resets search results
        self.search_results.clear()
        # checks that the results dictionary is there. the 'tracks' and 'items' are keywords for the spotify API, which is here: 
        # the syntax for iterating through the list and showing the results in pyqt is from this forum: https://stackoverflow.com/questions/39139488/search-iterate-through-qlistwidget-and-display-results
        # the exact wording for the spotify tracks in order for it to work with the API is from here: https://github.com/spotipy-dev/spotipy/issues/858. I think there needs to be exact variable namings, because changing 'tracks' to another string doesn't work
        if results and 'tracks' in results and 'items' in results['tracks']:
            for track in results['tracks']['items']:
                #list of the artists on the song
                artist_list = [artist['name'] for artist in track['artists']]
                #each item is formatted with the name of the song, and all the artists in order, I used .join because artist_list is a list and item is a string
                item = QListWidgetItem(track['name'] + ' - ' + ', '.join(artist_list))
                #I looked on the spotify API, and this is the syntax I need. I'm not exactly sure about why there's a thousand there, since it probably doesn't need to check for a thousand different songs, but I could be wrong and it still works in the end
                item.setData(1000, track['id'])
                #adds each entry to the search results
                self.search_results.addItem(item)
        #if no songs found
        else:
            print("No songs found")