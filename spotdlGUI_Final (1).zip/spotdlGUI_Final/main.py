'''
Name: Anshuman Arun
Class: Friday 1st Block Advanced Programming
Date: 5/9/2024
Final Project Desciption: This is a GUI for the SpotDL command line module
'''

#this is the main file. I imported all of the MVC components into here and then define the model, view, and controller. Most of this stuff is from the pyqt6 example code on Canvas

from PyQt6.QtWidgets import QApplication
from spotdlgui_controller import SpotDLController
from spotdlgui_model import SpotDLModel
from spotdlgui_view import SpotDLView

#defines all the components of the GUI and launches the program with view.show and app.exec
app = QApplication([])
model = SpotDLModel()
view = SpotDLView()
controller = SpotDLController(model, view)
view.show()
app.exec()

